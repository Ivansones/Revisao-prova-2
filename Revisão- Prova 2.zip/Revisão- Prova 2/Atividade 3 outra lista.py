dic={}
pedidios=[]
def adicionar():
    cliente=input("Qual é o nome do cliente:").title()
    pedido=input("Qual é o pedido:").title()
    dic[cliente]=pedido
def pesquisa():
    print(f"Os pedidos são {dic}")
def altera():
    novo_n=input("Qual cliente quer alterar:").title()
    if novo_n in dic:
        novo_p=input("Qual sera o novo pedido:").title()
        dic[novo_n]=novo_p
def excluir():
    remove=input("Qual cliente deseja remover:").title()
    dic.pop(remove)
def filtra():
    qual=input("Qual cliente deseja filtrar:").title()
    filtrado= dict(filter(lambda x: x!=qual,dic.items()))
    print("Os pedidos do clietne são",filtrado)
while True:
    print("#####"*10)
    print("Opções: C-Cadastrar cliente")
    print("        A-Alterar")
    print("        E-Excluir pedido")
    print("        F- Filtrar")
    print("        P-Pesquisar")
    print("        S-Sair")
    print("#####"*10)
    opcao=input("Qual escolha quer:").upper()
    if opcao=="C":
        adicionar()
    if opcao=="P":
        pesquisa()
    if opcao=="A":
        altera()
    if opcao=="E":
        excluir()
    if opcao=="F":
        filtra()
    if opcao=="S":
        print("Saindo")
        break
    