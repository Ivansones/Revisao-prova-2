dic={}
while True:
    print("######"*10)
    print("Opções:1-Adicionar funcionario")
    print("       2-Salario desejado")
    print("       3-Sair")
    print("######"*10)
    opcoe=int(input("Qual escolha quer fazer:"))
    if opcoe==1:
        nome=input("Qual é o nome do funcionario:")
        valor=float(input("Qual é o seu salario:")) 
        dic[nome]=valor
    if opcoe==2:
        desejo=float(input("Qual é o salario minimo:"))
    if opcoe==3:
        print("Saindo ")
        break
print(dic)

passados=dict(filter(lambda x : x[1]> desejo,dic.items()))
filtrados=dict(filter(lambda x : x[1]< desejo,dic.items()))
print(passados)
maior=dict(map(lambda x : (x[0],x[1]*1.15), filtrados.items()))
print(maior)

tudo= passados| maior

media=  sum(tudo.values())/len(tudo)
print(media)

print("O funcionario com maior salario é",max(tudo.items(), key=lambda x: x[1]))

print("O funcionario com menor salario é",min(tudo.items(), key=lambda x: x[1]))