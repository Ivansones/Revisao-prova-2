meses=["janeiro","Fevereiro"]
receitas=[]
despesas=[]
while True:
    print("#####"*10)
    print("Opções: 1-Adicionar receita e despesa")
    print("        2-Sair")
    print("#####"*10)
    opcoe=int(input("Qual dessas opções deseja escolher:"))
    if opcoe==1:
        valor=float(input("Qual valor de receita deseja adicionar:"))
        receitas.append(valor)
        tirar=float(input("Qual é o valor da despesa que deseja adicionar:"))
        despesas.append(tirar)
        print(receitas) 
        print(despesas)      
    if opcoe==2:
        print("Saindo")
        break
print(f"Os valores são da receita {receitas} e despesa {despesas}")
calculo=list(map(lambda x,y : x-y,receitas,despesas))
print(calculo)

media_anual= sum(calculo)/12
print(media_anual)
filtrado=list(filter(lambda x : x<0,calculo))
print(filtrado)
